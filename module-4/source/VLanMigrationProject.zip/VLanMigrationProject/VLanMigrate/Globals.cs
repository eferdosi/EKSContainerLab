﻿using System;
using System.Text;

using System.Diagnostics;
using System.Data;
using System.Linq;
using System.Globalization;

namespace VLanMigrate
{
    class Globals
    {
        public static string Truncate(string source, int length)
        {
            if (source.Length > length)
                source = source.Substring(0, length);
            return source;
        }

        public static string ConvertDataRowToXML(DataRow dr)
        {
            Debug.Assert(dr != null);
            StringBuilder stringBuilder = new StringBuilder();
            dr.Table.Columns.Cast<DataColumn>().ToList().ForEach(column =>
            {
                string tag = column.ColumnName.Replace(" ", "_x0020_");
                stringBuilder.AppendFormat("<{0}>{1}</{2}>", tag, dr[column], tag);
            });
            return stringBuilder.ToString();
        }

        public static string FromDBVal(object obj)
        {
            if (obj == null || obj == System.DBNull.Value)
            {
                return string.Empty;
            }
            if (obj is System.DateTime)
            {
                // ex:  "2014-01-01 00:00:00"
                System.DateTime dt = (System.DateTime)obj;
                DateTimeFormatInfo fmt = (new CultureInfo("en-US")).DateTimeFormat;
                return (dt.ToString(fmt.SortableDateTimePattern));
            }
            else
            {
                return obj.ToString();
            }
        }

        public static string GetField(DataRow row, string field)
        {
            if ((row != null) && (row.Table.Columns.Contains(field)))
            {
                return Globals.FromDBVal(row[field]);
            }
            else
                return string.Empty;
        }

        public static bool IsDiff(string current, string proposed, StringComparison rule = StringComparison.OrdinalIgnoreCase)
        {
            return (!string.Equals(current.Trim(), proposed.Trim(), rule));
        }

        public static bool IsSame(string current, string proposed, StringComparison rule = StringComparison.OrdinalIgnoreCase)
        {
            return (string.Equals(current.Trim(), proposed.Trim(), rule));
        }

        public static string TrimLeadingZeros(string s)
        {
            char[] trimchars = new char[] { '0', ' ' };
            return (s.TrimStart(trimchars));
        }

    }
}
